@echo off
setlocal
title CADR CUT — Uninstaller (CADR STUDIO)

net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath %~f0 -Verb RunAs"
    exit /b
)

set "SYS_CEP=%CommonProgramFiles(x86)%\Adobe\CEP\extensions\CADR_CUT"
if "%CommonProgramFiles(x86)%"=="" set "SYS_CEP=%CommonProgramFiles%\Adobe\CEP\extensions\CADR_CUT"
set "USR_CEP=%APPDATA%\Adobe\CEP\extensions\CADR_CUT"

echo Removing CADR CUT from Adobe Premiere Pro...
if exist "%SYS_CEP%" rmdir /s /q "%SYS_CEP%"
if exist "%USR_CEP%" rmdir /s /q "%USR_CEP%"
if exist "%CommonProgramFiles(x86)%\Adobe\CEP\extensions\CADR" rmdir /s /q "%CommonProgramFiles(x86)%\Adobe\CEP\extensions\CADR"

echo.
echo [SUCCESS] CADR CUT has been removed.
pause
