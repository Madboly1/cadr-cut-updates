#!/bin/bash
cd "$(dirname "$0")"
echo "===================================================================="
echo "                CADR STUDIO  |  CADR CUT v1.2.0"
echo "         Compatible with Premiere Pro 2020 - 2026 / 2027+"
echo "                   YOUR VISION. OUR FRAME."
echo "===================================================================="
echo ""

SRC_DIR="."
if [ -f "./Plugin/CSXS/manifest.xml" ]; then
  SRC_DIR="./Plugin"
fi

echo "[1/2] Enabling Adobe CEP PlayerDebugMode (CSXS 9 - 18 / 2020 - 2027+)..."
for V in 9 10 11 12 13 14 15 16 17 18; do
  defaults write com.adobe.CSXS.$V PlayerDebugMode 1
done

DEST_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/CADR_CUT"
echo "[2/2] Installing CADR CUT to: $DEST_DIR"
rm -rf "$DEST_DIR"
mkdir -p "$DEST_DIR"
cp -R "$SRC_DIR/client" "$DEST_DIR/"
cp -R "$SRC_DIR/CSXS" "$DEST_DIR/"
cp -R "$SRC_DIR/jsx" "$DEST_DIR/"
[ -d "$SRC_DIR/tools" ] && cp -R "$SRC_DIR/tools" "$DEST_DIR/"
[ -f "$SRC_DIR/.debug" ] && cp "$SRC_DIR/.debug" "$DEST_DIR/"
[ -f "$SRC_DIR/README.md" ] && cp "$SRC_DIR/README.md" "$DEST_DIR/"

echo ""
echo "===================================================================="
echo " [SUCCESS] CADR CUT v1.2.0 is installed! (Premiere Pro 2020 - 2027+)"
echo " Restart Adobe Premiere Pro -> Window -> Extensions -> CADR CUT"
echo "===================================================================="
read -p "Press Enter to close..."
